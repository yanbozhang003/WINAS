scaleCSI_v3:

wrote for "AntSel_eSNR4cbn_prt1.m", combine the rssi of two Rx antennas, and use the sum to scale the CSI. 